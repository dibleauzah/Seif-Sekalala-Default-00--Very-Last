import React from "react";

const ListingAmenties = () => {
  return <div>ListingAmenties</div>;
};

export default ListingAmenties;
