import React from "react";

const ListingMap = () => {
  return <div>ListingMap</div>;
};

export default ListingMap;
