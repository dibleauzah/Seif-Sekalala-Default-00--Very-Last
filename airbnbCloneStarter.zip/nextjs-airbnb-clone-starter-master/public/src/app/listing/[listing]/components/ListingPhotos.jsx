import React from "react";

const ListingPhotos = () => {
  return <div>ListingPhotos</div>;
};

export default ListingPhotos;
