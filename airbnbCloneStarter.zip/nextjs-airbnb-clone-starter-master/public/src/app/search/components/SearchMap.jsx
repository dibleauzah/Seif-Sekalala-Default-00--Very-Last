import React from "react";

const SearchMap = () => {
  return <div>SearchMap</div>;
};

export default SearchMap;
