import React from "react";

const SearchAddress = () => {
  return <div>SearchAddress</div>;
};

export default SearchAddress;
