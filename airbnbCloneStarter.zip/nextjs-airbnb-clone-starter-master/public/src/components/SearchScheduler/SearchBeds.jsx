import React from "react";

const SearchBeds = () => {
  return <div>SearchBeds</div>;
};

export default SearchBeds;
