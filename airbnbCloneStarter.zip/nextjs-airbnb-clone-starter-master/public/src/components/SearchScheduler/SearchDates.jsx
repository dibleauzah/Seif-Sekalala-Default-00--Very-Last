import React from "react";

const SearchDates = () => {
  return <div>SearchDates</div>;
};

export default SearchDates;
