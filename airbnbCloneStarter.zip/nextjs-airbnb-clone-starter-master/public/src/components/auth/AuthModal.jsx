import React from "react";

const AuthModal = () => {
  return <div>AuthModal</div>;
};

export default AuthModal;
