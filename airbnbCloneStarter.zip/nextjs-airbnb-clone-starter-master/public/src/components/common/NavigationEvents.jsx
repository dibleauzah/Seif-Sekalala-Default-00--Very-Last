import React from "react";

const NavigationEvents = () => {
  return <div>NavigationEvents</div>;
};

export default NavigationEvents;
