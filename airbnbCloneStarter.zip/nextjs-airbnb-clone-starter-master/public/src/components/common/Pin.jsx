import React from "react";

const Pin = () => {
  return <div>Pin</div>;
};

export default Pin;
