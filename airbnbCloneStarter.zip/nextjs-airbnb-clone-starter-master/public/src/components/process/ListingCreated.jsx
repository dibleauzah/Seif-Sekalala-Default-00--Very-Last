import React from "react";

const ListingCreated = () => {
  return <div>ListingCreated</div>;
};

export default ListingCreated;
