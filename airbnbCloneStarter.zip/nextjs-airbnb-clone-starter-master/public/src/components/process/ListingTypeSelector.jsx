import React from "react";

const ListingTypeSelector = () => {
  return <div>ListingTypeSelector</div>;
};

export default ListingTypeSelector;
