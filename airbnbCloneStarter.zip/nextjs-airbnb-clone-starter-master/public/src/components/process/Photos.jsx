import React from "react";

const Photos = () => {
  return <div>Photos</div>;
};

export default Photos;
