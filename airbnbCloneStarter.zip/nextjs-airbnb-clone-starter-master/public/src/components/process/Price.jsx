import React from "react";

const Price = () => {
  return <div>Price</div>;
};

export default Price;
