import React from "react";

const ProcessAmeneties = () => {
  return <div>ProcessAmeneties</div>;
};

export default ProcessAmeneties;
