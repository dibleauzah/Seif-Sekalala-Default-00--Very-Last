import React from "react";

const StepOneStarter = () => {
  return <div>StepOneStarter</div>;
};

export default StepOneStarter;
