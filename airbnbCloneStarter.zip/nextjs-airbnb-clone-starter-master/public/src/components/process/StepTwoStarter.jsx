import React from "react";

const StepTwoStarter = () => {
  return <div>StepTwoStarter</div>;
};

export default StepTwoStarter;
