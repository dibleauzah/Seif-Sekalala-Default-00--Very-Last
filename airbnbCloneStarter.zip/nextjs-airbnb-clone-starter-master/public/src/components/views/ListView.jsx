import React from "react";

const ListView = () => {
  return <div>ListView</div>;
};

export default ListView;
