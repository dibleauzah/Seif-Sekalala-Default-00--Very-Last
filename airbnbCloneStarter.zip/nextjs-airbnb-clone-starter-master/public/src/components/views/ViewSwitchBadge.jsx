import React from "react";

const ViewSwitchBadge = () => {
  return <div>ViewSwitchBadge</div>;
};

export default ViewSwitchBadge;
