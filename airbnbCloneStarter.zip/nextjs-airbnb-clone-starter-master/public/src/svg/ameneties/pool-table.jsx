import React from "react";

export default function PoolTable() {
  return <div>PoolTable</div>;
}
